﻿/* Name: Hao Zhong
 * Course: DVP2
 * Term: April 2021
 * Assignment: 3.1 Alpha */

using System;
namespace GuessMyName.Models
{
    public class MessageModel
    {
        // Properties
        public string Text { get; set; }
        public string Sender { get; set; }
        public DateTime Time { get; set; }
    }
}
